<?php 
function getUserData(){
    $f = fopen(....) or die("Unable to open file!");
    while(!feof($f)){
       ...
    }
    $users=array();
    foreach($data as $e){
       ....
    }
    return ...;
}
?>