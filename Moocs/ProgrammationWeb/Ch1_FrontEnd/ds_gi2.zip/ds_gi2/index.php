<?php 
session_start();
include "./tools.php";
//recuperer les donner depuis le fichier data.txt
//$_userdata=array("username"=>array("passwor"=>pass,"mail"=>mail, "score"=>score))
$_userdata=getUserData();
$_SESSION["userdata"]=$_userdata;
if(count($_SESSION)>1){
   //aller vers home.php...
}
else
    //aller vers login.php...
?>